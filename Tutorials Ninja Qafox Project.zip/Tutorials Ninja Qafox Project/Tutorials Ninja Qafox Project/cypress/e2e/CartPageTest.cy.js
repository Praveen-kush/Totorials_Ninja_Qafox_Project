import CartPage from "../support/pageobject1/CartPage.cy";
import CheckoutPage from "../support/pageobject1/CheckoutPage.cy";
import ProductListingPage from "../support/pageobject1/ProductListingPage.cy";
import FooterPage from "../support/pageobject1/FooterPage.cy";


describe('Cart Functionality Tests', () => {
    const cartPage = new CartPage();
    const productListingPage = new ProductListingPage();
    const checkoutPage = new CheckoutPage();
    const footerPage = new FooterPage();

    it('Validate cart display', () => {
        productListingPage.visit();
        productListingPage.addProductToCart('Product Name 1'); // Replace with the actual product name
        productListingPage.addProductToCart('Product Name 2'); // Add multiple products

        cartPage.visit();
        cartPage.validateCartItems();
        cartPage.validateTotalPrice('$100'); // Example expected total
    });

    it('Remove items from cart and validate total', () => {
        cartPage.removeProductsFromCart();
        cartPage.validateEmptyCartMessage();
    });

    it('Checkout process and validation', () => {
        cartPage.visit();
        cartPage.validateCartItems();
        cartPage.validateTotalPrice('$0'); // After removing all items, total should be 0
        checkoutPage.visit();
        checkoutPage.validateCheckoutDetails();
        checkoutPage.completeCheckout();
    });

    it('Footer links validation', () => {
        footerPage.validateFooterLink('Home', '/index.html');
        footerPage.validateFooterLink('Contact', '/contact.html');
    });
});
