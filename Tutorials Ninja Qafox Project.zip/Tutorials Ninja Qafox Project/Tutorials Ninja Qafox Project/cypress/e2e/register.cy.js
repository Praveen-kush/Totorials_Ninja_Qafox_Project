describe('Facebook Login Page', () => {
    it(() => {
      cy.visit('https://www.facebook.com/'); // Visit the Login page
    });
  
    it('should log in with valid credentials', () => {
      cy.get('#email').type('valid_user@example.com'); // Enter valid email
      cy.get('#pass').type('ValidPassword123'); // Enter valid password
      cy.get('button[name="login"]').click(); // Click Login
  
      // Assertion
      cy.url().should('not.include', '/login/'); // Verify login success
    });
  
    it('should show error for invalid credentials', () => {
      cy.get('#email').type('invalid_user@example.com'); // Enter invalid email
      cy.get('#pass').type('WrongPassword'); // Enter wrong password
      cy.get('button[name="login"]').click(); // Click Login
  
      // Assertion
      cy.contains('The email or mobile number you entered isn’t connected to an account.').should('be.visible'); // Verify error message
    });
  
    it('should show an error for blank fields', () => {
      cy.get('button[name="login"]').click(); // Click Login with blank fields
  
      // Assertion
      cy.contains('The email address or mobile number you entered isn’t connected to an account.').should('be.visible'); // Verify error message
    });
  });
  