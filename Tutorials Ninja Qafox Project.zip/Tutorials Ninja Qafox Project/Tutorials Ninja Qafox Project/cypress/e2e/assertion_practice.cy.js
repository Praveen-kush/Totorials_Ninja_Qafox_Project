// describe('assertion practice', () => {
//     it('', () => {
//         cy.get("https://www.facebook.com/r.php");
//         // cy.visit("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
//         // cy.get('[type="submit"]').should('be.visible');

//         // // cy.get('[name="username"]').type("Admin").should('have.value','Admin');
//         // // cy.get('[type="password"]').type('admin123').should('have.value','admin123');
//         // cy.get('[type="submit"]').click();
        
//     });
    
// });
describe('Facebook Sign-Up Page', () => {
  it('', () => {
    cy.visit('https://www.facebook.com/r.php',{"failOnStatusCode": false});
   
    
  });
    // it(() => {
    //   cy.visit('https://www.facebook.com/r.php'),{failOnStatusCode: false};
    //   // Visit the Sign-Up page
    // });
  
    // it('should sign up with valid data', () => {
    //   cy.get('#u_0_m').type('John'); // First Name
    //   cy.get('#u_0_o').type('Doe'); // Last Name
    //   cy.get('#u_0_r').type('john.doe@example.com'); // Email
    //   cy.get('#u_0_u').type('john.doe@example.com'); // Re-enter Email
    //   cy.get('#password_step_input').type('StrongPassword123'); // Password
  
    //   // Select Date of Birth
    //   cy.get('#day').select('15');
    //   cy.get('#month').select('Apr');
    //   cy.get('#year').select('1990');
  
    //   // Select Gender
    //   cy.get('input[name="sex"]').check('2'); // '2' represents Male (you can update according to DOM)
  
    //   cy.get('button[name="websubmit"]').click(); // Click Sign Up
  
    //   // Assertion
    //   cy.url().should('not.include', '/r.php'); // Verify the page redirects
    // });
  
    // it('should show an error for missing required fields', () => {
    //   cy.get('#u_0_o').type('Doe'); // Only Last Name
    //   cy.get('button[name="websubmit"]').click(); // Click Sign Up
  
    //   // Assertion
    //   cy.contains('What’s your name?').should('be.visible'); // Verify error message
    });
  
  