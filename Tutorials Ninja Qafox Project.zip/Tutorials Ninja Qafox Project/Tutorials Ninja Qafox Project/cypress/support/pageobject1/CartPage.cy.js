class CartPage {
    visit() {
        cy.visit('https://www.demoblaze.com/cart.html');
    }

    validateCartItems() {
        cy.get('.table-responsive').should ('be.visible');
        cy.get('.success').should ('be.visible');
        cy.get('.success').each(($row)=>{
            cy.wrap($row).within(()=>{
                cy.get('td').eq(0).should('be.visible','img');
                cy.get('td').eq(1).should('be.visible','Samsung galaxy s6');
                cy.get('td').eq(2).should('be.visible','360');
                cy.get('td').eq(3).should('be.visible','Delete');

            });
            cy.wrap($row).within(()=>{
                cy.get('td').eq(0).should('be.visible','img');
                cy.get('td').eq(1).should('be.visible','Samsung galaxy s6');
                cy.get('td').eq(2).should('be.visible','360');
                cy.get('td').eq(3).should('be.visible','Delete');

            });
            cy.wrap($row).within(()=>{
                cy.get('td').eq(0).should('be.visible','img');
                cy.get('td').eq(1).should('be.visible','Samsung galaxy s6');
                cy.get('td').eq(2).should('be.visible','360');
                cy.get('td').eq(3).should('be.visible','Delete');

            });
        });
        // cy.get('.cart-table tbody tr').should('have.length.at.least', 1); // Validate cart items
        // cy.get('.cart-table tbody tr').each(($row) => {
        //     cy.wrap($row).within(() => {
        //         cy.get('.name').should('exist'); // Validate product names
        //         cy.get('.price').should('exist'); // Validate product prices
        //         cy.get('.quantity').should('exist'); // Validate product quantities
        //     });
        // });
    }

    removeProductsFromCart() {
        cy.contains('Delete').click(); // Remove  products
    }

    validateTotalPrice(expectedTotal) {
        cy.get('#col-lg-1').should('be.visible'); // Validate total price
    }

    validateEmptyCartMessage() {
        cy.get('.page-header h2').should('contain.text', 'Your cart is empty'); // Validate empty cart message
        cy.get('.btn-success').should('be.disabled'); // Validate checkout button is disabled
    }
}
export default CartPage;
