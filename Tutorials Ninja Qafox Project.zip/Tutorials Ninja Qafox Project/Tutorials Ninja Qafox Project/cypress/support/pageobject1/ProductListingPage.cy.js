class ProductListingPage {
    visit() {
        cy.visit('https://www.demoblaze.com/');
    }

    addProductToCart(productName) {
        cy.contains('Samsung galaxy s6').click(); // Navigate to product detail page
        cy.contains('Add to cart').click();
    }   
    applyPriceFilter(minPrice, maxPrice) {
        cy.get('.price-filter-range').invoke('val', [minPrice, maxPrice]).trigger('change'); // Apply price filter
    }

    validateProductInCart(productName) {
        cy.contains('.cartTable', productName).should('exist'); // Validate product in cart
    }
}
export default ProductListingPage;
