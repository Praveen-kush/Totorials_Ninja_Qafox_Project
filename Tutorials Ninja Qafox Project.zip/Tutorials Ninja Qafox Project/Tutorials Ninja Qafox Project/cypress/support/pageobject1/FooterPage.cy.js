class FooterPage {
    validateFooterLink(linkText, url) {
        cy.contains(linkText).click(); // Click footer link
        cy.url().should('include', url); // Validate redirection
        cy.go('back'); // Go back to the previous page
    }
}
export default FooterPage;
