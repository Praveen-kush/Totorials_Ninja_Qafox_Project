class CheckoutPage {
    visit() {
        cy.visit("https://www.demoblaze.com/");
        cy.get('.btn-success').click(); // Navigate to checkout page
    }

    validateCheckoutDetails() {
        cy.get('.order-summary').should('exist'); // Validate order summary
        cy.get('.cart-summary .name').should('exist'); // Validate product names
        cy.get('.cart-summary .price').should('exist'); // Validate product prices
    }

    completeCheckout() {
        cy.get('#orderButton').click(); // Complete checkout process
        cy.get('.thank-you-message').should('exist'); // Validate thank you message
    }
}
export default CheckoutPage;
