class ProductListingPage {
    visit() {
        cy.visit('https://www.demoblaze.com'); // Visit the product listing page
    }

    addProductToCart(productName) {
        cy.get('.name').contains(productName).click(); // Find product by name and click to view details
        cy.get('.btn-primary').contains('Add to cart').click(); // Click "Add to cart" button
        cy.get('.success').should('be.visible').and('contain', 'Product added'); // Confirm product added
        cy.get('.nav-link').contains('Cart').click(); // Navigate to the cart page
    }

    applyFilter(priceRange) {
        cy.get('#min-price').clear().type(priceRange.min); // Set min price
        cy.get('#max-price').clear().type(priceRange.max); // Set max price
        cy.get('#filter-button').click(); // Apply price filter
    }
}

export default ProductListingPage;
