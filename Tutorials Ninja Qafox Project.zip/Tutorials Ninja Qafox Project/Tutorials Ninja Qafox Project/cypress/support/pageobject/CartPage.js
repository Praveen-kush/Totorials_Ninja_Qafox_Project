class CartPage {
    visitCart() {
        cy.visit('https://www.demoblaze.com/cart.html');
    }

    validateProductDetails(productName, productPrice) {
        cy.get('.table-responsive tbody tr').each(($row) => {
            cy.wrap($row).within(() => {
                cy.get('td:nth-child(2)').should('contain.text', productName); // Validate product name
                cy.get('td:nth-child(3)').should('contain.text', productPrice); // Validate product price
            });
        });
    }
    removeProduct(rowIndex) {
        cy.get('.table-responsive tbody tr')
            .eq(rowIndex)
            .find('td:last-child button')
            .click();
        cy.wait(2000); // Wait for the cart to update
    }

    validateCartTotal(expectedTotal) {
        cy.get('#totalp').should('have.text', expectedTotal);
    }
}

export default CartPage;
