class CheckoutPage {
    navigateToCheckout() {
        cy.get('.btn-primary').contains('Proceed to checkout').click(); // Click "Proceed to Checkout" button
    }

    verifyCheckoutPageDetails(cartDetails) {
        cy.get('.product-name').each(($el, index) => {
            cy.wrap($el).should('contain.text', cartDetails.products[index].name); // Verify product names
        });

        cy.get('.product-quantity').each(($el, index) => {
            cy.wrap($el).should('have.value', cartDetails.products[index].quantity); // Verify quantities
        });

        cy.get('.product-price').each(($el, index) => {
            cy.wrap($el).should('contain.text', cartDetails.products[index].price); // Verify prices
        });

        cy.get('.total-price').should('contain.text', cartDetails.totalPrice); // Verify total price
    }

    completeCheckoutAndVerifyConfirmation(orderDetails) {
        cy.get('.order-confirmation').should('contain.text', orderDetails.orderSummary); // Verify order summary
        cy.get('.confirmation-email').should('contain.text', orderDetails.emailInfo); // Verify confirmation email
    }
}

export default CheckoutPage;
