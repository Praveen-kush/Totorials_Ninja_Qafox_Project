class RegisterPage{
    RegisterPage(){
        cy.visit("https://www.facebook.com/r.php");
        cy.xpath('(//div[@id="content"])[1]').should('be.visible');
        
        // cy.get('[type="submit"]').should('be.visible');

    }
}