class NavPhonesAndPDAs{
    iphones_and_pdas_click(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=24'])[1]").click()
    }
    first_product(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/product&path=24&product_id=28'])[1]").click()
        cy.xpath("(//input[@class='form-control'])[2]").click().type('{backspace}').type(5)
        cy.get("button.btn.btn-primary.btn-lg.btn-block").click()
        cy.contains('div','Success: You have added ')
        .should('exist')
        .and('be.visible')

    }
    second_product(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/product&path=24&product_id=40'])[1]").click()
        cy.get("#input-quantity").click().type('{backspace}').type(5)
        cy.xpath("//button[@id='button-cart']").click()
        cy.contains('div','Success: You have added ')
        .should('exist')
        .and('be.visible')
        
    }
    third_product(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/product&path=24&product_id=29'])[1]").click()
        cy.get("#input-quantity").click().type('{backspace}').type(5)
        cy.xpath("//button[@id='button-cart']").click()
        cy.contains('div','Success: You have added ')
        .should('exist')
        .and('be.visible')

    }

}
export default NavPhonesAndPDAs