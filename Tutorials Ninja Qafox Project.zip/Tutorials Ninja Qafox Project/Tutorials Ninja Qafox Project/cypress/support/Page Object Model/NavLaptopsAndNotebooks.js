class LaptopsNotebooks{
    laptop_notebook_click(){
        cy.xpath("(//a[@class='dropdown-toggle'])[3]").click();
    }
   laptop_notebook_Macs(){
    cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=18_46'])[1]").click()
    cy.contains('p', 'There are no products to list in this category.')
         .should('exist')  
         .and('be.visible'); 
        cy.get("a.btn.btn-primary").click()
   }
   laptop_notebook_Windows(){
    cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=18_45'])[1]").click()
    cy.contains('p', 'There are no products to list in this category.')
         .should('exist')  
         .and('be.visible'); 
        cy.get("a.btn.btn-primary").click()
   }
   
    
}
export default LaptopsNotebooks