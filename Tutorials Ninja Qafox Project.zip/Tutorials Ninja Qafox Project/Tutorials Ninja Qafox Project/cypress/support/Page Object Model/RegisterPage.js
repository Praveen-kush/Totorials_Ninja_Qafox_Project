class RegisterPage{
    RegisterPage(){
       cy.visit("https://tutorialsninja.com/demo/");//Check url
       cy.xpath('(//span[@class="hidden-xs hidden-sm hidden-md"])[3]').click({force: true});//Check My Account
       cy.xpath('//a[@href="https://tutorialsninja.com/demo/index.php?route=account/register"]').click();
       cy.xpath('(//input[@name="firstname"])[1]').type('Praveen');
       cy.xpath('(//input[@name="lastname"])[1]').type('Kumar');
       cy.xpath('(//input[@name="email"])[1]').type('praveen0808@gmail.com');
       cy.xpath('(//input[@name="telephone"])[1]').type('7309647468');
       cy.xpath('(//input[@name="password"])[1]').type('Praveen@0808');
       cy.xpath('(//input[@name="confirm"])[1]').type('Praveen@0808');
       cy.xpath('(//input[@name="newsletter"])[2]').click();
       cy.xpath('(//input[@name="agree"])[1]').click();
       cy.xpath('(//input[@value="Continue"])[1]').click();//class="btn btn-primary"
       cy.xpath('(//input[@class="btn btn-primary"])[1]').click();
       //Suppose you have already login Email error comeing then
       cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/login"])[2]').click();
       cy.get('#input-email').type('praveen0808@gmail.com');
       cy.get('#input-password').type('Praveen@0808');
       cy.get('form > .btn').click();
       cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/logout"])[2]').click();
       cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=common/home"])[3]').click();
    }
}
export default RegisterPage;