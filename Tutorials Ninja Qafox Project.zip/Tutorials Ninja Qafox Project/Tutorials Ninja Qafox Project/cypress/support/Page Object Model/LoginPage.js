class LoginPage {

    //Login in my account
    LoginInMyAccount() {
        cy.visit("https://tutorialsninja.com/demo/");//Check url
        //cy.get('.dropdown').click();
        cy.xpath('(//li[@class="dropdown"])[1]').click();//Check My Account
        cy.xpath('//a[@href="https://tutorialsninja.com/demo/index.php?route=account/login"]').click();
    }

    //Enter the positive credentials
    PTLoginCredentialsAccept() {
        cy.xpath('(//input[@placeholder="E-Mail Address"])[1]').type('praveen0808@gmail.com');
        cy.xpath('(//input[@placeholder="Password"])[1]').type('Praveen@0808');
        cy.xpath('(//input[@value="Login"])[1]').click();
    }

    //Enter the negative credentials-wrong email
    NTLoginCredentials1() {
        cy.xpath('(//input[@placeholder="E-Mail Address"])[1]').type('praveenkumar0808');
        cy.xpath('(//input[@placeholder="Password"])[1]').type('Praveen@0808');
        cy.xpath('(//input[@value="Login"])[1]').click();

        cy.xpath('//div[@class="alert alert-danger alert-dismissible"]').should('be.visible').should('have.text','Warning: No match for E-Mail Address and/or Password.');
    }

    //Enter the negative credentials-wrong email
    NTLoginCredentials2() {
        cy.xpath('(//input[@placeholder="E-Mail Address"])[1]').type('Pravee080@gmail.com');
        cy.xpath('(//input[@placeholder="Password"])[1]').type('Praveen@0808');
        cy.xpath('(//input[@value="Login"])[1]').click();
        cy.xpath('//div[@class="alert alert-danger alert-dismissible"]').should('be.visible').should('have.text','Warning: No match for E-Mail Address and/or Password.');
    }

    //Enter the negative credentials-wrong password
    NTLoginCredentials3() {
        cy.xpath('(//input[@placeholder="E-Mail Address"])[1]').type('praveen0808');
        cy.xpath('(//input[@placeholder="Password"])[1]').type('Praveen@0887');
        cy.xpath('(//input[@value="Login"])[1]').click();

        cy.xpath('//div[@class="alert alert-danger alert-dismissible"]').should('be.visible').should('have.text','Warning: No match for E-Mail Address and/or Password.');
    }

    //password is empty 
    NTLoginCredentials4() {
        cy.xpath('(//input[@placeholder="E-Mail Address"])[1]').type('praveen0808');
        cy.xpath('(//input[@placeholder="Password"])[1]').type('{selectall}{backspace} ');
        cy.xpath('(//input[@value="Login"])[1]').click();

        cy.xpath('//div[@class="alert alert-danger alert-dismissible"]').should('be.visible').should('have.text','Warning: No match for E-Mail Address and/or Password.');
    }

    //email is empty
    NTLoginCredentials5() {
        cy.xpath('(//input[@placeholder="E-Mail Address"])[1]').type('{selectall}{backspace} ');
        cy.xpath('(//input[@placeholder="Password"])[1]').type('Praveen@0808');
        cy.xpath('(//input[@value="Login"])[1]').click();

        cy.xpath('//div[@class="alert alert-danger alert-dismissible"]').should('be.visible').should('have.text','Warning: No match for E-Mail Address and/or Password.');
    }
}

export default LoginPage;