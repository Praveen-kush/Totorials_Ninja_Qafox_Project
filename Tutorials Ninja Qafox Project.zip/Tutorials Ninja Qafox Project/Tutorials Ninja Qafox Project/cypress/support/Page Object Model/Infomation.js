class Infomation {
    Infomation() {
        cy.visit("https://tutorialsninja.com/demo/");
        //Information
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=information/information&information_id=4"])[1]').click(); //about us
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=information/information&information_id=6"])[1]').click(); //Delivery Information
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=information/information&information_id=3"])[1]').click(); //Privacy Policy
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=information/information&information_id=5"])[1]').click(); //Terms & Conditions
        //Customer Service
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=information/contact"])[1]').click(); //Contact Us
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/return/add"])[1]').click(); //Returns
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=information/sitemap"])[1]').click(); //Site Map
         //Extras
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=product/manufacturer"])[1]').click();//Brands
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/voucher"])[1]').click();//Gift Certificates
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=affiliate/login"])[1]').click();//Affiliate
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=product/special"])[1]').click();//Specials
        //My Account
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/account"])[1]').click();//My Account
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/order"])[1]').click();//Order History
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/wishlist"])[1]').click();//Wish List
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/newsletter"])[1]').click();//Newsletter
    }
}
export default Infomation