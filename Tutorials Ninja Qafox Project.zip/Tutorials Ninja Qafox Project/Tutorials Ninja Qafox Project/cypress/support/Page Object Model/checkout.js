class checkout{

    checkout_click(){
        cy.xpath("//a[@title='Checkout']").click()
        cy.contains('div','Products marked with *** are not available in the desired quantity or not in stock!')
        .should('exist')
        .and('be.visible')
    }
}
export default checkout