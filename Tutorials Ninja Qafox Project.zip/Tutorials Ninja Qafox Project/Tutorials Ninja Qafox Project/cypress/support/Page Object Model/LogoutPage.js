class LogoutPage{
    Logout(){

        //cy.get('.caret').click();
        
        // cy.xpath('(//a[@class="dropdown-toggle"])[1]').click();
        // Cypress.on("uncaught:exception", (err, runnable) => {
        //     return false;
        //   });
        //cy.xpath('(//li[@class="dropdown"])[1]').click();
        //cy.visit("https://tutorialsninja.com/demo/index.php?route=account/account");
        cy.xpath('(//span[@class="caret"])[1]').click();
        //cy.xpath('(//li[@href="https://tutorialsninja.com/demo/index.php?route=account/account"])[1]').click();
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=account/logout"])[1]').click();
        
    }


    Clicking_on_Continue(){
        cy.xpath('(//a[@href="https://tutorialsninja.com/demo/index.php?route=common/home"])[3]').click();
    }

}
export default LogoutPage