class NavDesktop{
    desktop_click(){
        cy.xpath("(//a[@class='dropdown-toggle'])[2]").click();

    }
    desktop_PC(){
        //clicking the PC link and redirected to the Pc page 
        cy.xpath("//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=20_26']").click({force: true});
        // if there is no product avalible in the page , it informs and there is a continue button to go back to the home page and continue shopping.
        cy.contains('p', 'There are no products to list in this category.')
         .should('exist')  
         .and('be.visible'); 
        cy.get("a.btn.btn-primary").click()

    }
    desktop_Mac(){
        //clicking the Mac sub-category of the Desktop category 
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=20_27'])").click({force:true});
        cy.url().should('include','/category&path=20_27')
        //choosing a product and viewing it redirects to the page.
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/product&path=20_27&product_id=41'])[2]").click()
        cy.url().should('include','/product&path=20_27&product_id=41')
        //add to cart and update and addto cart
        cy.get("#input-quantity").click().type('{backspace}').type(5)
        cy.xpath("//button[@id='button-cart']").click()
        // cy.contains('i', ' 5 item(s) - 478.61€')
        //  .should('exist')  
        //  .and('be.visible'); 

        //add to wishlist and confirm 
        cy.xpath("(//button[@class='btn btn-default'])[1]").click()
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=common/home'])[1]").click()

    }
}
export default NavDesktop;